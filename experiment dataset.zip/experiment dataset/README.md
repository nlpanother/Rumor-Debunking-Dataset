**Submission Dataset Release**

- Experiment dataset for the submission [A Novel Fact Checking Knowledge Constraints based Rumor Debunking Text Generation Framework for Small Data Set]

- train.tsv is the training dataset used in the experiment section.
- test.tsv is the testing dataset used in the experiment section.